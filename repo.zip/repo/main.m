clear; clc; close all;

% Setup directories
here = fileparts(mfilename('fullpath'));
addpath(fullfile(here, 'functions'));
figdir = fullfile(here, 'figures');
if ~exist(figdir, 'dir'), mkdir(figdir); end
rng(42); % Reproducible noise

%% ---------------- Base Configuration -----------------------------------
cfg.Fs  = 8000;          
cfg.T   = 0.05;          
cfg.fm  = 300;           
cfg.osr = 10;            
cfg.nbits = 8;           
cfg.xmax  = 1;           
cfg.line  = 'NRZ';       
cfg.sps_bit = 32;        
cfg.cycles_per_bit = 4;  
cfg.reconstruct = true;

twin = 0.010;            

%% ================================================================
%  PART 1: CONDITIONAL STAGE PLOTS (C1 - C4)
% ================================================================
fprintf('Generating Conditional Stage Plots (C1-C4)...\n');

% FIGURE C1 — Full pipeline at three channel SNRs
snr_set = [20, -3, -10];
labels  = {'Clean (SNR = 20 dB)', 'Moderate (SNR = -3 dB)', 'Noisy (SNR = -10 dB)'};
R = cell(1,3);
for k = 1:3
    R{k} = run_chain(cfg, snr_set(k));
end

f = figure('Name','Pipeline across SNR','Position',[50 50 1500 950]);
for k = 1:3
    r  = R{k};
    wa = r.t_a <= twin; ws = r.t_s <= twin;

    subplot(4,3,k);
    plot(r.t_a(wa)*1e3, r.x_a(wa), 'b', 'LineWidth', 1.0); hold on;
    stairs(r.t_s(ws)*1e3, r.xq(ws), 'r', 'LineWidth', 1.2);
    grid on; ylim([-1.6 1.6]); title(labels{k}, 'FontSize', 10);
    if k == 1, ylabel('Amplitude'); legend('Original','Quantized','Location','best'); end

    subplot(4,3,k+3);
    ns = 8*cfg.sps_bit; n = 0:ns-1;
    plot(n/cfg.sps_bit, r.tx(1:ns), 'b', 'LineWidth', 1.0); hold on;
    plot(n/cfg.sps_bit, r.rx(1:ns), 'Color', [0.75 0.75 0.75]);
    grid on;
    if k == 1, ylabel('Tx / Rx'); legend('Transmitted','Received','Location','best'); end

    subplot(4,3,k+6);
    plot(r.t_a(wa)*1e3, r.x_a(wa), 'b', 'LineWidth', 1.0); hold on;
    plot(r.t_a(wa)*1e3, r.x_rec(wa), 'r--', 'LineWidth', 1.4);
    grid on; ylim([-2.5 2.5]);
    title(sprintf('BER = %.2e   MSE = %.2e', r.ber, r.mse), 'FontSize', 9);
    if k == 1, ylabel('Reconstructed'); legend('Original','Reconstructed','Location','best'); end

    subplot(4,3,k+9);
    plot(r.t_a(wa)*1e3, r.x_a(wa) - r.x_rec(wa), 'm');
    grid on; ylim([-2.5 2.5]); xlabel('Time (ms)');
    if k == 1, ylabel('Error'); end
end
save_fig(f, figdir, 'C1_pipeline_vs_snr');

% FIGURE C2 — NRZ vs Manchester
snr_line = -3; schemes = {'NRZ', 'Manchester'}; labels2 = {'NRZ (1 chip/bit)', 'Manchester (2 chips/bit)'};
R2 = cell(1,2);
for j = 1:2, c = cfg; c.line = schemes{j}; R2{j} = run_chain(c, snr_line); end

f = figure('Name','Line code comparison','Position',[50 50 1300 800]);
for j = 1:2
    r = R2{j};
    subplot(3,2,j);
    nbl = 24; c = r.chips(1:nbl*r.cpb);
    stairs((0:numel(c))/r.cpb, [c c(end)], 'LineWidth', 1.5);
    ylim([-1.5 1.5]); grid on; title(labels2{j}); if j == 1, ylabel('Line code'); end

    subplot(3,2,j+2);
    ns = 6*cfg.sps_bit; n = 0:ns-1;
    plot(n/cfg.sps_bit, r.tx(1:ns), 'b', 'LineWidth', 1.0); grid on;
    if j == 1, ylabel('Modulated'); end

    subplot(3,2,j+4);
    wa = r.t_a <= twin;
    plot(r.t_a(wa)*1e3, r.x_a(wa), 'b', 'LineWidth', 1.0); hold on;
    plot(r.t_a(wa)*1e3, r.x_rec(wa), 'r--', 'LineWidth', 1.4);
    grid on; ylim([-2.5 2.5]); xlabel('Time (ms)');
    title(sprintf('Recon.: BER = %.2e   MSE = %.2e', r.ber, r.mse), 'FontSize', 10);
    if j == 1, ylabel('Reconstructed'); end
end
save_fig(f, figdir, 'C2_line_code_comparison');

% FIGURE C3 — Quantization depth
snr_q = 15; bitset = [4, 6, 8, 10];
f = figure('Name','Quantization depth','Position',[50 50 1500 900]);
for k = 1:numel(bitset)
    c = cfg; c.nbits = bitset(k); r = run_chain(c, snr_q);
    wa = r.t_a <= twin; ws = r.t_s <= twin;

    subplot(3,4,k);
    plot(r.t_a(wa)*1e3, r.x_a(wa), 'b'); hold on;
    stairs(r.t_s(ws)*1e3, r.xq(ws), 'r', 'LineWidth', 1.2);
    grid on; ylim([-1.5 1.5]); title(sprintf('%d bits (%d levels)', bitset(k), 2^bitset(k)));
    if k == 1, ylabel('Quantized'); end

    subplot(3,4,k+4);
    plot(r.t_a(wa)*1e3, r.x_a(wa), 'b'); hold on;
    plot(r.t_a(wa)*1e3, r.x_rec(wa), 'r--', 'LineWidth', 1.3);
    grid on; ylim([-1.5 1.5]); if k == 1, ylabel('Reconstructed'); end

    subplot(3,4,k+8);
    plot(r.t_a(wa)*1e3, r.x_a(wa) - r.x_rec(wa), 'm');
    grid on; xlabel('Time (ms)'); title(sprintf('MSE = %.2e', r.mse), 'FontSize', 9);
    if k == 1, ylabel('Error'); end
end
save_fig(f, figdir, 'C3_quantization_depth');

% FIGURE C4 — Stage walkthrough
snr_walk = 0; r = run_chain(cfg, snr_walk); Tp = 1/cfg.fm; wa = r.t_a <= Tp; ws = r.t_s <= Tp;
f = figure('Name','Stage walkthrough','Position',[50 50 1300 1000]);

subplot(4,2,1); plot(r.t_a(wa)*1e3, r.x_a(wa), 'b', 'LineWidth', 1.4); grid on; title('1. Source m(t)'); xlabel('Time (ms)'); ylabel('Amplitude');
subplot(4,2,2); stem(r.t_s(ws)*1e3, r.x_s(ws), 'r', 'filled'); grid on; title(sprintf('2. Sampled @ %d Hz', cfg.Fs)); xlabel('Time (ms)'); ylabel('Amplitude');
subplot(4,2,3); stairs(r.t_s(ws)*1e3, r.xq(ws), 'r', 'LineWidth', 1.3); hold on; plot(r.t_s(ws)*1e3, r.x_s(ws), 'k.', 'MarkerSize', 6); grid on; title(sprintf('3. Quantized (%d bits)', cfg.nbits)); xlabel('Time (ms)'); ylabel('Amplitude');
subplot(4,2,4); nb = 3*cfg.nbits; stairs(0:nb, [r.bits(1:nb) r.bits(nb)], 'LineWidth', 1.5); hold on; for kk = 0:3, plot([kk*cfg.nbits kk*cfg.nbits], [-0.3 1.3], 'k:'); end; ylim([-0.3 1.3]); grid on; title('4. PCM bits (first 3 samples)'); xlabel('Bit index'); ylabel('Bit');
subplot(4,2,5); nbl = 16; c = r.chips(1:nbl*r.cpb); stairs((0:numel(c))/r.cpb, [c c(end)], 'LineWidth', 1.5); ylim([-1.5 1.5]); grid on; title(sprintf('5. Line-coded (%s)', cfg.line)); xlabel('Bit periods'); ylabel('Level');
subplot(4,2,6); ns = 4*cfg.sps_bit; n = 0:ns-1; plot(n/cfg.sps_bit, r.tx(1:ns), 'b'); hold on; stairs((0:numel(r.chips(1:4*r.cpb)))/r.cpb, [r.chips(1:4*r.cpb) r.chips(4*r.cpb)], 'r--', 'LineWidth', 1.1); grid on; title('6. BPSK modulated'); xlabel('Bit periods'); ylabel('Amplitude');
subplot(4,2,7); plot(n/cfg.sps_bit, r.rx(1:ns), 'Color', [0.7 0.7 0.7]); hold on; plot(n/cfg.sps_bit, r.tx(1:ns), 'b', 'LineWidth', 1.0); grid on; title(sprintf('7. Received (channel SNR = %g dB)', snr_walk)); xlabel('Bit periods'); ylabel('Amplitude');
subplot(4,2,8); plot(r.t_a(wa)*1e3, r.x_a(wa), 'b', 'LineWidth', 1.2); hold on; plot(r.t_a(wa)*1e3, r.x_rec(wa), 'r--', 'LineWidth', 1.5); stem(r.t_s(ws)*1e3, r.xq_hat(ws), 'g.'); grid on; title(sprintf('8. Reconstructed (MSE = %.2e)', r.mse)); xlabel('Time (ms)'); ylabel('Amplitude'); legend('Original','Reconstructed','Rx samples','Location','best');
save_fig(f, figdir, 'C4_stage_walkthrough');


%% ================================================================
%  PART 2: PERFORMANCE ANALYSIS (BER, MSE, SHANNON)
% ================================================================
fprintf('Running Monte-Carlo Sweep for BER, MSE, and Shannon Capacity...\n');

snr_vec  = -14:1:10;     % sweep range (dB)
ntrials  = 100;          % Monte-Carlo runs per SNR point
cfg.reconstruct = false; % MSE is measured at the samples to save time

nS = numel(snr_vec);
ber_sim = zeros(1,nS); mse_sim = zeros(1,nS);

for i = 1:nS
    nerr = 0; nbit = 0; mse_acc = 0;
    for k = 1:ntrials
        rk = run_chain(cfg, snr_vec(i));
        nerr = nerr + rk.nerr; nbit = nbit + numel(rk.bits);
        mse_acc = mse_acc + rk.mse;
    end
    ber_sim(i) = nerr/nbit;
    mse_sim(i) = mse_acc/ntrials;
end

Px      = mean(r.x_s.^2);
snr_out = 10*log10(Px ./ mse_sim);
mse_q   = r.mse_q;

% FIGURE 10: BER vs SNR
ebn0_lin = 10.^(snr_vec/10) * cfg.sps_bit/2;
ber_th   = 0.5*erfc(sqrt(ebn0_lin));

f = figure('Name','BER');
ber_plot = ber_sim; ber_plot(ber_plot == 0) = NaN;
semilogy(snr_vec, ber_plot, 'o-', 'LineWidth', 1.3); hold on;
semilogy(snr_vec, ber_th, 'k--', 'LineWidth', 1.3);
xlabel('Channel SNR (dB)'); ylabel('Bit error rate'); grid on;
legend('Simulated','Theory: 0.5 erfc(\surd(E_b/N_0))','Location','southwest');
title('BER vs channel SNR (coherent BPSK)');
save_fig(f, figdir, '10_ber_vs_snr');

% FIGURE 11: MSE vs SNR
f = figure('Name','MSE vs SNR','Position',[100 100 700 650]);
subplot(2,1,1);
semilogy(snr_vec, mse_sim, 'o-', 'LineWidth', 1.3); hold on;
semilogy([snr_vec(1) snr_vec(end)], [mse_q mse_q], 'r--', 'LineWidth', 1.2);
xlabel('Channel SNR (dB)'); ylabel('MSE'); grid on;
legend('End-to-end MSE','Quantization-noise floor','Location','northeast');
title('Reconstruction MSE vs channel SNR');
subplot(2,1,2);
plot(snr_vec, snr_out, 'o-', 'LineWidth', 1.3); hold on;
plot([snr_vec(1) snr_vec(end)], [6.02*cfg.nbits+1.76 6.02*cfg.nbits+1.76], 'r--', 'LineWidth', 1.2);
xlabel('Channel SNR (dB)'); ylabel('Output SNR (dB)'); grid on;
legend('Reconstructed-signal SNR','6.02N + 1.76 dB (quantization limit)','Location','southeast');
title('Output SNR vs channel SNR');
save_fig(f, figdir, '11_mse_vs_snr');

% FIGURE 12: Shannon Capacity
Rb    = r.Rb;                               
Rchip = Rb * r.cpb;
B     = 2 * Rchip;                          
snrB  = 10.^(snr_vec/10) * (r.fs_tx/2) / B; 
C     = B * log2(1 + snrB);                 

snrB_min   = 2^(Rb/B) - 1;                  
snr_shan   = 10*log10(snrB_min * B/(r.fs_tx/2));        
ebn0_shan  = snr_shan + 10*log10(cfg.sps_bit/2);
ik = find(mse_sim < 2*mse_q, 1);            
snr_knee   = snr_vec(ik);
ebn0_knee  = snr_knee + 10*log10(cfg.sps_bit/2);

f = figure('Name','Shannon','Position',[100 100 750 700]);
subplot(2,1,1);
plot(snr_vec, C/1e3, 'LineWidth', 1.5); hold on;
plot([snr_vec(1) snr_vec(end)], [Rb Rb]/1e3, 'r--', 'LineWidth', 1.3);
plot([snr_shan snr_shan], ylim, 'k:', 'LineWidth', 1.5);
xlabel('Channel SNR (dB)'); ylabel('kbit/s'); grid on;
legend('Shannon capacity C = B log_2(1+SNR)', sprintf('PCM bit rate R_b = %g kbit/s', Rb/1e3), ...
       'C = R_b (Shannon limit)', 'Location','northwest');
title(sprintf('Capacity vs required rate (B = %g kHz)', B/1e3));

subplot(2,1,2);
semilogy(snr_vec, mse_sim, 'o-', 'LineWidth', 1.3); hold on;
semilogy([snr_vec(1) snr_vec(end)], [mse_q mse_q], 'r--');
plot([snr_shan snr_shan], ylim, 'k:', 'LineWidth', 1.5); 
plot([snr_knee snr_knee], ylim, 'g-', 'LineWidth', 1.5);
xlabel('Channel SNR (dB)'); ylabel('MSE'); grid on;
legend('End-to-end MSE','Quantization floor','Shannon limit','Practical knee','Location','northeast');
title('Where the channel becomes the bottleneck');
save_fig(f, figdir, '12_shannon');

fprintf('\nAll 7 figures saved to: %s\n', figdir);