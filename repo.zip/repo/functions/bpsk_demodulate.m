function [soft, chips_hat] = bpsk_demodulate(rx, sps, cycles)
%BPSK_DEMODULATE  Coherent correlator (matched filter) + hard decision.
%   soft is scaled so a noiseless chip gives +/-1.
n       = 0:(numel(rx) - 1);
carrier = cos(2*pi*(cycles/sps)*n);
soft    = (2/sps) * sum(reshape(rx .* carrier, sps, []), 1);
chips_hat = 2*(soft > 0) - 1;
end
