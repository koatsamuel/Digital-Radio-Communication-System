function x_rec = reconstruct_signal(xs_hat, t_s, t_a, Fs)
%RECONSTRUCT_SIGNAL  Ideal (Whittaker-Shannon) sinc interpolation of the
%   received samples onto the fine "analog" time grid t_a.
u = (t_a(:) - t_s(:).') * Fs;
S = ones(size(u));
nz = (u ~= 0);
S(nz) = sin(pi*u(nz)) ./ (pi*u(nz));
x_rec = (S * xs_hat(:)).';
end
