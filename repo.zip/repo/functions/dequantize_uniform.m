function xq = dequantize_uniform(idx, nbits, xmax)
%DEQUANTIZE_UNIFORM  Inverse of quantize_uniform (index -> amplitude).
delta = 2*xmax/2^nbits;
xq    = -xmax + (idx + 0.5)*delta;
end
