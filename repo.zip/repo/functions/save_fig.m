function save_fig(fig, figdir, name)
%SAVE_FIG  Save a figure as PNG into figdir.
saveas(fig, fullfile(figdir, [name '.png']));
end
