function fig = draw_block_diagram()
%DRAW_BLOCK_DIAGRAM  Block diagram of the full system.
fig = figure('Name','Block diagram','Position',[80 80 1400 380]);
ax = axes('Position',[0 0 1 1]); hold(ax,'on'); axis(ax,'off');
xlim([0 15.5]); ylim([-0.8 3.4]);
w = 1.8; h = 0.9; gap = 2.1;
top = {'Source\n(sine, fm)','Sampler\n(Fs)','Quantizer\n(N bits)','PCM encoder\n(bits)', ...
       'Line coder\n(NRZ / Manch.)','BPSK\nmodulator','AWGN\nchannel'};
bot = {'BPSK\ndemodulator','Line\ndecoder','PCM\ndecoder','De-quantizer', ...
       'Sinc\ninterpolation','Reconstructed\nsignal'};
y1 = 2.2; y2 = 0.2;
for i = 1:numel(top)
    x = 0.4 + (i-1)*gap;
    fc = [0.85 0.92 1.0]; if i == 7, fc = [1.0 0.88 0.80]; end
    rectangle('Position',[x y1 w h],'Curvature',0.15,'FaceColor',fc,'LineWidth',1.2);
    text(x+w/2, y1+h/2, sprintf(top{i}), 'HorizontalAlignment','center','FontSize',9);
    if i < numel(top)
        quiver(x+w, y1+h/2, gap-w, 0, 0, 'k','MaxHeadSize',0.8,'LineWidth',1.3);
    end
end
for j = 1:numel(bot)
    i = 8 - j;                                  % slot 7 (under channel) down to 2
    x = 0.4 + (i-1)*gap;
    rectangle('Position',[x y2 w h],'Curvature',0.15,'FaceColor',[0.88 1.0 0.88],'LineWidth',1.2);
    text(x+w/2, y2+h/2, sprintf(bot{j}), 'HorizontalAlignment','center','FontSize',9);
    if j < numel(bot)
        quiver(x, y2+h/2, -(gap-w), 0, 0, 'k','MaxHeadSize',0.8,'LineWidth',1.3);
    end
end
xc = 0.4 + 6*gap + w/2;
quiver(xc, y1, 0, -(y1-y2-h), 0, 'k','MaxHeadSize',0.8,'LineWidth',1.3);
text(0.4, 3.3, 'TRANSMITTER', 'FontWeight','bold');
text(0.4, 1.5, 'RECEIVER (right to left)', 'FontWeight','bold');
end
