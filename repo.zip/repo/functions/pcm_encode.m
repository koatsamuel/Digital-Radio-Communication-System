function bits = pcm_encode(idx, nbits)
%PCM_ENCODE  Integer indices -> serial bit stream (MSB first), row vector.
idx = idx(:);
B   = zeros(numel(idx), nbits);
for k = 1:nbits
    B(:,k) = mod(floor(idx / 2^(nbits-k)), 2);
end
bits = reshape(B.', 1, []);
end
