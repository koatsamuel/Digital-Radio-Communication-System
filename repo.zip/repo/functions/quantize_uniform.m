function [idx, xq] = quantize_uniform(x, nbits, xmax)
%QUANTIZE_UNIFORM  Mid-rise uniform quantizer on [-xmax, xmax].
%   idx : integer level index 0 .. 2^nbits-1
%   xq  : quantized amplitude (centre of the cell)
L     = 2^nbits;
delta = 2*xmax/L;
idx   = floor((x + xmax)/delta);
idx   = min(max(idx, 0), L-1);          % clip the +xmax edge case
xq    = -xmax + (idx + 0.5)*delta;
end
