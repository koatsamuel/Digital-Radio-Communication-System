function idx = pcm_decode(bits, nbits)
%PCM_DECODE  Serial bit stream (MSB first) -> integer indices, row vector.
B   = reshape(bits, nbits, []).';
idx = (B * (2.^(nbits-1:-1:0)).').';
end
