function [tx, carrier] = bpsk_modulate(chips, sps, cycles)
%BPSK_MODULATE  Rectangular-pulse BPSK.
%   sps    : samples per chip
%   cycles : carrier cycles per chip (integer -> clean coherent detection)
n       = 0:(sps*numel(chips) - 1);
carrier = cos(2*pi*(cycles/sps)*n);
tx      = repelem(chips, sps) .* carrier;       % unit amplitude, power 0.5
end
