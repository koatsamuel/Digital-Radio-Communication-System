function h = vline(x, style, label)
%VLINE  Draw a vertical line (works on any MATLAB release).
yl = ylim;
h  = plot([x x], yl, style, 'LineWidth', 1.2);
ylim(yl);
if nargin > 2 && ~isempty(label)
    set(h, 'DisplayName', label);
end
end
