function r = run_chain(cfg, snr_db)
%RUN_CHAIN  One pass through the complete communication system.
%   Source -> Sampling -> Quantization -> PCM -> Line coding -> BPSK ->
%   AWGN -> Demod -> Line decode -> PCM decode -> Dequantize -> Reconstruct
%   All intermediate signals are returned in the struct r.

% --- Transmitter ---------------------------------------------------------
[r.t_a, r.x_a, r.t_s, r.x_s] = generate_message(cfg);
[r.idx, r.xq] = quantize_uniform(r.x_s, cfg.nbits, cfg.xmax);
r.bits        = pcm_encode(r.idx, cfg.nbits);
[r.chips, r.cpb] = line_encode(r.bits, cfg.line);

r.sps    = cfg.sps_bit / r.cpb;               % samples per chip
r.cycles = cfg.cycles_per_bit / r.cpb;        % carrier cycles per chip
r.tx     = bpsk_modulate(r.chips, r.sps, r.cycles);

% --- Channel -------------------------------------------------------------
[r.rx, r.sigma] = awgn_channel(r.tx, snr_db);

% --- Receiver ------------------------------------------------------------
[r.soft, r.chips_hat] = bpsk_demodulate(r.rx, r.sps, r.cycles);
r.bits_hat = line_decode(r.soft, cfg.line);
r.idx_hat  = pcm_decode(r.bits_hat, cfg.nbits);
r.xq_hat   = dequantize_uniform(r.idx_hat, cfg.nbits, cfg.xmax);
if cfg.reconstruct
    r.x_rec = reconstruct_signal(r.xq_hat, r.t_s, r.t_a, cfg.Fs);
end

% --- Metrics (computed at the sample instants) ---------------------------
r.nerr    = sum(r.bits ~= r.bits_hat);
r.ber     = r.nerr / numel(r.bits);
r.mse     = mean((r.x_s - r.xq_hat).^2);      % end-to-end
r.mse_q   = mean((r.x_s - r.xq).^2);          % quantization only
r.snr_out = 10*log10(mean(r.x_s.^2) / r.mse);

% --- Rates ---------------------------------------------------------------
r.Rb    = cfg.Fs * cfg.nbits;                 % bit rate (bits/s)
r.fs_tx = r.Rb * cfg.sps_bit;                 % simulation sample rate (Hz)
end
