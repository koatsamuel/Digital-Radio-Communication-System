function bits = line_decode(soft, scheme)
%LINE_DECODE  Soft chip values (correlator outputs) -> bits.
%   Manchester uses the soft difference of the two half-bits, which is
%   better than deciding each chip separately.
switch upper(scheme)
    case 'NRZ'
        bits = double(soft > 0);
    case 'MANCHESTER'
        d    = soft(1:2:end) - soft(2:2:end);
        bits = double(d > 0);
    otherwise
        error('Unknown line code "%s".', scheme);
end
end
