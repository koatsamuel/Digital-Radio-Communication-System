function [rx, sigma] = awgn_channel(tx, snr_db)
%AWGN_CHANNEL  Add white Gaussian noise at a given *measured* SNR (dB).
%   Equivalent to awgn(tx, snr_db, 'measured') but needs no toolbox.
%   snr_db = Inf gives a noiseless channel.
if isinf(snr_db)
    rx = tx; sigma = 0; return;
end
Ps    = mean(tx.^2);
sigma = sqrt(Ps / 10^(snr_db/10));
rx    = tx + sigma*randn(size(tx));
end
