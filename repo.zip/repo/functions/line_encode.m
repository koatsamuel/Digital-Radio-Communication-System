function [chips, cpb] = line_encode(bits, scheme)
%LINE_ENCODE  Polar line coding. Output is a +/-1 "chip" sequence.
%   'NRZ'        : 1 -> +1, 0 -> -1                (1 chip / bit)
%   'Manchester' : 1 -> [+1 -1], 0 -> [-1 +1]      (2 chips / bit)
%   cpb = chips per bit.
switch upper(scheme)
    case 'NRZ'
        chips = 2*bits - 1;
        cpb   = 1;
    case 'MANCHESTER'
        chips = zeros(1, 2*numel(bits));
        chips(1:2:end) =  (2*bits - 1);
        chips(2:2:end) = -(2*bits - 1);
        cpb   = 2;
    otherwise
        error('Unknown line code "%s" (use ''NRZ'' or ''Manchester'').', scheme);
end
end
