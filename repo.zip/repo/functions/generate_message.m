function [t_a, x_a, t_s, x_s] = generate_message(cfg)
%GENERATE_MESSAGE  Source + sampler.
%   t_a, x_a : "analog" reference (oversampled by cfg.osr, for plotting/MSE)
%   t_s, x_s : samples taken at cfg.Fs
t_s = 0:1/cfg.Fs:cfg.T;
x_s = sin(2*pi*cfg.fm*t_s);
t_a = 0:1/(cfg.Fs*cfg.osr):cfg.T;
x_a = sin(2*pi*cfg.fm*t_a);
end
