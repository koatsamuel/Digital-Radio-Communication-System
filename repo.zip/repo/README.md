# Digital Radio Communication System

Language: MATLAB

## Overview
This project builds a complete end-to-end digital radio communication link from first principles in MATLAB. The pipeline encompasses analogue sampling, PCM quantization, line coding, BPSK modulation, transmission over an AWGN channel, coherent demodulation, and sinc interpolation for signal reconstruction.

The project quantifies system performance by measuring the Bit Error Rate (BER) and reconstruction Mean Squared Error (MSE) across various Signal-to-Noise Ratios (SNR). It compares the simulated results against closed-form theoretical limits (BPSK BER and Shannon capacity) to identify whether the channel noise or the quantization process acts as the primary bottleneck.

## Chain
Source (300 Hz sine) -> Sampling (8 kHz) -> 8-bit uniform quantizer -> PCM bits
-> Line code (NRZ or Manchester) -> BPSK -> AWGN channel -> coherent BPSK
demodulator -> line decoder -> PCM decoder -> de-quantizer -> sinc reconstruction.

## How to run
1. Open MATLAB and `cd` into the repo folder.
2. Run `main` (type `main` in the Command Window).
3. All figures are saved to `figures/` and a summary is printed to the console.

Runtime is about a minute (100 Monte-Carlo runs per SNR point).
Reduce `ntrials` in `main.m` for a faster run.
The MATLAB script (`main.m`) generates a comprehensive set of figures categorized into conditional stage plots and performance analyses.

## Configuration (top of `main.m`)
| Parameter | Meaning | Default |
|---|---|---|
| `cfg.nbits` | PCM bits per sample | 8 |
| `cfg.line` | `'NRZ'` or `'Manchester'` | `'NRZ'` |
| `demo_snr` | channel SNR for the stage-by-stage plots (dB) | -6 |
| `snr_vec` | SNR sweep range (dB) | -14:1:10 |
| `ntrials` | Monte-Carlo runs per SNR | 100 |

## Structure

main.m                  entry point: runs everything, saves figures
functions/
  generate_message.m    source + sampler
  quantize_uniform.m    mid-rise quantizer      dequantize_uniform.m
  pcm_encode.m          indices -> bits         pcm_decode.m
  line_encode.m         NRZ / Manchester        line_decode.m
  bpsk_modulate.m       BPSK                    bpsk_demodulate.m
  awgn_channel.m        AWGN at measured SNR
  reconstruct_signal.m  sinc interpolation
  run_chain.m           one full pass of the system, returns all stages
  draw_block_diagram.m, save_fig.m, vline.m   helpers
figures/                saved plots


## Notes on definitions
* **Channel SNR** is the measured SNR of the passband signal over the whole simulation
  bandwidth (same definition as `awgn(x, snr, 'measured')`).
  Eb/N0 = SNR + 10 log10(sps_bit/2) = SNR + 12.04 dB for the default settings.
* **MSE** is computed between the original samples and the received, de-quantized samples.
  Sinc interpolation is exact at the sample instants, so this equals the sampled-domain
  reconstruction error.
* **Shannon bandwidth** B is the null-to-null bandwidth of rectangular-pulse BPSK:
  2 x chip rate (128 kHz for NRZ, 256 kHz for Manchester).

### Installation & Execution
1. Clone the repository or download the project files.
2. Ensure the project directory contains the `main.m` script and a `functions/` folder (containing `run_chain.m` and `save_fig.m`).
3. Open MATLAB and navigate to the project directory.
4. Run the main script:
   ```matlab
   main
   ```
5. All generated figures will be saved automatically to the `figures/` directory.